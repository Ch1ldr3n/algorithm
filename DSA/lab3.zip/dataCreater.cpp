//
// Created by q1uyj on 2021/5/28.
//

#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <cstring>

using namespace std;

const int N = 8500001;
bool st[N]; // 判断某个key是否在树中
int size;
int q[1000010], idx; // 存储过的key值


void makeData1() {
    srand(time(NULL));
    memset(st, 0, sizeof st);
    int n = 1000000;
    size = idx = 0;
    FILE *pFile = NULL;
    pFile = fopen("in.txt", "w");
    fprintf(pFile, "%d\n", n);
    for (int i = 0; i < n; ++i) {
        if (size == 0) {
            int x = (rand() * rand()) % N; // 0 - 8500000
            fprintf(pFile, "A %d\n", x);
            size++;
            st[x] = true;
            q[idx++] = x;
        } else {
            if (rand() % 10) {
                if (rand() % 3 == 0) {
                    int x = rand() * rand() % N;
                    while (st[x]) x = rand() * rand() % N;
                    fprintf(pFile, "A %d\n", x);
                    st[x] = true;
                    q[idx++] = x;
                    size++;
                } else {
                    int x = rand() * rand() % N;
                    fprintf(pFile, "C %d\n", x);
                }
            } else {
                int x = rand() * rand() % idx;
                while (!st[q[x]]) x = rand() * rand() % idx;
                fprintf(pFile, "B %d\n", q[x]);
                size--;
                st[q[x]] = false;
            }
        }

    }

    fclose(pFile);

}

void makeData2() {
    srand(time(0));
    size = idx = 0;
    memset(st, 0, sizeof(st));
    int n = 1000000, lim = 10;
    FILE *pFile;
    pFile = fopen("in.txt", "w");
    int last = rand() * rand() % N;
    while (n--) {
        if (size == 0) {
            int x = (last - lim / 2 + rand() % lim + N) % N;
            last = x;
            fprintf(pFile, "A %d\n", x);
            st[x] = 1;
            q[idx++] = x;
            size++;
        } else {
            if (rand() % 10) {
                if (rand() % 3 == 0) {
                    int x = (last - lim / 2 + rand() % lim + N) % N;
                    while (st[x]) x = rand() * rand() % N;
                    last = x;
                    st[x] = 1;
                    q[idx++] = x;
                    size++;
                    fprintf(pFile, "A %d\n", x);
                } else {
                    last = (last - lim / 2 + rand() % lim + N) % N;
                    fprintf(pFile, "C %d\n", last);
                }
            } else {
                int x = rand() * rand() % idx;
                while (!st[q[x]]) x = rand() * rand() % idx;
                last = q[x];
                fprintf(pFile, "B %d\n", q[x]);
                size--;
                st[q[x]] = 0;
            }
        }
    }
    fclose(pFile);
}

int main() {
    FILE *pFile;
    pFile = fopen("testData.txt", "w");
    system("g++ splay.cpp -std=c++11 -O2 -o splay.exe");
    system("g++ AVL.cpp -std=c++11 -O2 -o AVL.exe");
    int cnt = 10;

    fputs("----------------------------data1----------------------------\n", pFile);

    fputs("splay:\n", pFile);
    double sumTime = 0;
    for (int i = 0; i < cnt; ++i) {
        fprintf(pFile, "test %d: ", i + 1);
        makeData1();
        char copyFile[] = "copy/y in.txt in1_0.txt";
        copyFile[18] = '0' + i;
        system(copyFile);

        int startTime = clock();
        system("splay.exe < in.txt > out.txt");
        int pTime = clock() - startTime;
        fprintf(pFile, "time: %d ms\n", pTime);
        sumTime += pTime;
    }
    fprintf(pFile, "average: %.2lf ms\n", sumTime / cnt);

    fputs("AVL:\n", pFile);
    sumTime = 0;
    for (int i = 0; i < cnt; ++i) {
        fprintf(pFile, "test %d: ", i + 1);
        char copyFile[] = "copy/y in1_0.txt in.txt";
        copyFile[11] = '0' + i;
        system(copyFile);

        int startTime = clock();
        system("AVL.exe < in.txt > out.txt");
        int pTime = clock() - startTime;
        fprintf(pFile, "time: %d ms\n", pTime);
        sumTime += pTime;
    }
    fprintf(pFile, "average: %.2lf ms\n", sumTime / cnt);


    fputs("\n-----------------------data2---------------\n", pFile);

    fputs("splay:\n", pFile);
    sumTime = 0;
    for (int i = 0; i < cnt; ++i) {
        makeData2();
        fprintf(pFile, "test%d: ", i + 1);
        char backup[] = "copy/y in.txt in2_0.txt";
        backup[18] = '0' + i;
        system(backup);
        unsigned int start = clock();
        system("splay.exe < in.txt > out.txt");
        unsigned int end = clock() - start;
        sumTime += end;
        fprintf(pFile, "time: %d ms\n", end);
    }
    fprintf(pFile, "average: %.2lf ms\n", sumTime / cnt);

    fputs("AVL: \n", pFile);
    sumTime = 0;
    for (int i = 0; i < cnt; ++i) {
        char r[] = "copy/y in2_0.txt in.txt";
        r[11] = '0' + i;
        fprintf(pFile, "test%d: ", i + 1);
        system(r);
        unsigned int start = clock();
        system("AVL.exe < in.txt > out.txt");
        unsigned int end = clock() - start;
        fprintf(pFile, "time: %d ms \n", end);
        sumTime += end;
    }
    fprintf(pFile, "average: %.2lf ms\n", sumTime / cnt);
    fclose(pFile);
    return 0;
}